﻿namespace RestAPI_test1.Model
{
    public class Plugin
    {
        public string Name { get; set; }    
    }
}
