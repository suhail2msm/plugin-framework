﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RestAPI_test1.Util;
using System.Net.Http.Headers;

namespace RestAPI_test1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ImageController : ControllerBase
    {

        // get available plugins
        [HttpGet]
        public JsonResult GetAvailablePlugins()
        {
            return new JsonResult(Ok("Available Plugins"));
        }

        [HttpGet]
        public JsonResult GetData()
        {
            /*
             {
               library_name: "",
               class_name: "",
                methods: [ "", "" ]
             }
             */

            //test
            String result = LoadDll.Load();

          return new JsonResult(Ok("Success result: " + result));
        }

        [HttpPost, DisableRequestSizeLimit]
        public async Task<IActionResult> Upload()
        {
            try
            {
                /* Improve Reding from a Form Body

                  var formCollection = await Request.ReadFormAsync();
                  var file = formCollection.Files.First();

                 */

                // var file = Request.Form.Files[0];
                var formCollection = await Request.ReadFormAsync();
                var file = formCollection.Files.First();

                var folderName = Path.Combine("Resources", "Images");
                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
                if (file.Length > 0)
                {
                    var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                    var fullPath = Path.Combine(pathToSave, fileName);
                    var dbPath = Path.Combine(folderName, fileName);
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }
                    return Ok(new { dbPath });
                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex}");
            }
        }
    }
}
