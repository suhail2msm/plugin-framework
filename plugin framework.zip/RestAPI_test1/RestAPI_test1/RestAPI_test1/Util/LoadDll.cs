﻿using System.Reflection;
using Tweetinvi.Security;

namespace RestAPI_test1.Util
{
    public class LoadDll
    {
        public static String Load()
        {
            string fileName = "ClassLibrary.dll";
            string dllFile = Path.Combine(Environment.CurrentDirectory, @"Resources\Images\", fileName);

            //  string dllFile = "RestAPI_test1.Resources.Images.ClassLibrary.dll";
      
            //  string dllFile = @"D:\1 - SJ SW Engineering\Test\ConsoleApp_Make_DLL\ClassLibrary\bin\Debug\net6.0\ClassLibrary.dll";
            var assemly = Assembly.LoadFile(dllFile);

            var type = assemly.GetType("ClassLibrary.MathService");

            var obj = Activator.CreateInstance(type);

            //Execute methods
            var method = type.GetMethod("Multiply");
            var result = method.Invoke(obj, new object[] {10,4});

            return result.ToString();
        }
    }
}
